/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.llenarvectorn;

import java.util.Scanner;



/**
 *
 * @author ESTUDIANTE19
 */
public class LlenarvectorN {

    public static void main(String[] args) {
       int n = 0;
       int vector[];
      
       Scanner teclado = new Scanner(System.in);
       System.out.println("digite");
       n = teclado.nextInt();
       System.out.println("LLene valores");
       vector = new int[n];
       for(int a = 0; a < n;a++){    
       vector[a] = teclado.nextInt();   
       }
        System.out.println("Vector: ");
       for (int i = n - 0; i >= 1; i--) {
          
            System.out.print(i + "");
        }
       
       
       
      
        
       
      
       

        
        
 
        
    }
}
