/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.llenaraleatoriaca;

/**
 *
 * @author ESTUDIANTE19
 */
public class LLenarAleatoriaCa {

    public static void main(String[] args) {
        String inicio[] = null;
        METODO.inicio(inicio);
        
    }
}
