/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.llenaraleatoriaca;

import java.util.Scanner;



/**
 *
 * @author ESTUDIANTE19
 */
public class METODO {
    public static void inicio( String vector1[]){
     
       vector1 = new String[12];
       vector1[0] = "enero";
       vector1[1] = "febrero";
       vector1[2] = "marzo";
       vector1[3] = "abril";
       vector1[4] = "mayo";
       vector1[5] = "junio";
       vector1[6] = "julio";
       vector1[7] = "agosto";        
       vector1[8] = "septiembre"; 
       vector1[9] = "octubre"; 
       vector1[10] ="noviembre";
       vector1[11] ="diciembre";
       
       METODO.resultado(vector1);
       
       
       
    }
    
    public static void resultado( String vector1[]){
        int suma = 0;
        int i;
        int a;
        Scanner teclado =new Scanner(System.in);
         for( a = 0; a < vector1.length;a++){
            System.out.println(vector1[a]); 
           for(i = 1;i < 2;i++){
               System.out.println("ingresa el monto ");
           }
            i = teclado.nextInt();
            suma += i;

            }
        System.out.println("total ascendido de las ventas máximas y total de ventas "+suma);
        int respuesta = suma /12;
        System.out.println("promedio de las ventas fue " + respuesta);
        
    }
}
