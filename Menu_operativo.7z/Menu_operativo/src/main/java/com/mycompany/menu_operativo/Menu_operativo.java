/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.menu_operativo;

import javax.swing.JOptionPane;

/**
 *
 * @author ESTUDIANTE19
 */
public class Menu_operativo {

    public static void main(String[] args) {
       
        int option;
        int resultado = 0;
        int num2;
        int num3;
        operaciones.welcome();
        operaciones.tabla();   
        option = Integer.parseInt(JOptionPane.showInputDialog(null,"ingresa la opcion de 1 a 6"));
        num2 = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el numero"));
        num3 = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el numero"));
        
        
        operaciones.suma(option,num2,num3,resultado);
        operaciones.resta(option, num2, num3, resultado);
        operaciones.multiplicacion(option, num2, num3, resultado);
        operaciones.division(option, num2, num3, resultado);
        operaciones.salir();
        
        
        
        

    }
}
