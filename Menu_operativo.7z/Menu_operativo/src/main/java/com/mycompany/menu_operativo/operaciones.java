/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.menu_operativo;

import javax.swing.JOptionPane;

/**
 *
 * @author ESTUDIANTE19
 */
public class operaciones {
    
    public static void welcome(){
        JOptionPane.showMessageDialog(null, "bienvenido");
    }
    public static void tabla(){
         JOptionPane.showMessageDialog(null, "1) suma \n2) resta \n3) multiplicacion \n4) division");
    }
    
    public static int suma(int num1,int num2,int num3,int sumatoria){
       if(num1 == 1){
           sumatoria = num2 + num3;
           JOptionPane.showMessageDialog(null,"El resultado es " + sumatoria);
       }
       return sumatoria;
    }
     public static int resta(int num1,int num2,int num3,int resta){
       if(num1 == 2){
           resta = num2 - num3;
           JOptionPane.showMessageDialog(null,"El resultado es " + resta);
       }
       return resta;
    }
     public static int multiplicacion(int num1,int num2,int num3,int multiplicacion){
       if(num1 == 3){
           multiplicacion = num2 * num3;
           JOptionPane.showMessageDialog(null,"El resultado es " + multiplicacion);
       }
       return multiplicacion;
    }
      public static int division(int num1,int num2,int num3,int division){
       if(num1 == 4){
           division = num2 * num3;
           JOptionPane.showMessageDialog(null,"El resultado es " + division);
       }
       return division;
    }
       public static void salir(){
       JOptionPane.showMessageDialog(null, "ha finalizado la operacion");
    }
}

  

